import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.tree import DecisionTreeClassifier
import xgboost as xgb
from sklearn.naive_bayes import GaussianNB
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
from mpl_toolkits.mplot3d import Axes3D
"""Load the dataset"""
df = pd.read_csv("dataset_med.csv")
print(df.head())

""" print 0th row to 5th row (that means total of 6 rows) for the cancer data"""
row_data = df.loc[0:40, 'survived']
print(row_data)

"""read only column names of the given dataset"""
df_columns_name = df.columns
print(df_columns_name)
"""print the unique data"""
finding_unique_category_unique = df['survived'].unique()
print(finding_unique_category_unique)
"""print the nunique data"""
finding_unique_category_nunique = df['survived'].nunique()
print(finding_unique_category_nunique)
"""print the count  data"""
finding_unique_category_total_count = df['survived'].count()
print(finding_unique_category_total_count)


"""Convert categorical columns to numerical values"""
# Properly encode all categorical variables to fix the string conversion error
# Create a copy of the dataframe for processing
df_processed = df.copy()

# Encode categorical variables
label_encoders = {}
categorical_columns = ['gender', 'country', 'cancer_stage', 'family_history', 'smoking_status', 'treatment_type']
print(df.head())
for col in categorical_columns:
    le = LabelEncoder()
    df_processed[col + '_encoded'] = le.fit_transform(df_processed[col])
    label_encoders[col] = le

# Convert dates to numerical features
df_processed['diagnosis_date'] = pd.to_datetime(df_processed['diagnosis_date'])
df_processed['end_treatment_date'] = pd.to_datetime(df_processed['end_treatment_date'])
df_processed['treatment_duration'] = (df_processed['end_treatment_date'] - df_processed['diagnosis_date']).dt.days

# Select features for modeling (only numerical columns)
feature_columns = ['age', 'bmi', 'cholesterol_level', 'hypertension', 'asthma', 'cirrhosis',
                  'other_cancer', 'treatment_duration'] + [col + '_encoded' for col in categorical_columns]

X = df_processed[feature_columns].fillna(0)  # Handle any missing values
y = df_processed['survived']


# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print("Data preprocessing completed successfully")
print("Training set shape:", X_train_scaled.shape)
print("Test set shape:", X_test_scaled.shape)
print("Class distribution in training set:")
print(y_train.value_counts(normalize=True))

X = df[['age','gender', 'cancer_stage', 'smoking_status', 'treatment_type']]
y = df['survived']

"""Split the data into training and testing sets"""
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("Data Split into Training and Testing Sets:")
print("Training Features (X_train)")
print(X_train.head())
print("Training Target (y_train)")
print(y_train.head())
print("Testing Features (X_test)")
print(X_test.head())
print("Testing Target (y_test)")
print(y_test.head())

# Now train a logistic regression model with properly encoded data

# Train logistic regression model
model = LogisticRegression(random_state=42, max_iter=1000)
model.fit(X_train_scaled, y_train)

# Make predictions
y_pred = model.predict(X_test_scaled)
y_pred_proba = model.predict_proba(X_test_scaled)[:, 1]

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
auc = roc_auc_score(y_test, y_pred_proba)

print("Model Training Complete!")
print(f"Test Accuracy: {accuracy:.4f}")
print(f"AUC Score: {auc:.4f}")
print("\
Classification Report:")
print(classification_report(y_test, y_pred))

# Feature importance
feature_importance = pd.DataFrame({
    'feature': feature_columns,
    'importance': abs(model.coef_[0])
}).sort_values('importance', ascending=False)

print("\
Top 10 Most Important Features:")
print(feature_importance.head(10))

# Fix the n_features parameter issue - sklearn's DecisionTreeClassifier doesn't have this parameter
# Let's use the correct parameters for sklearn

print("Training sklearn Decision Tree with correct parameters...")

# Train sklearn decision tree with proper parameters
sklearn_dt = DecisionTreeClassifier(
    min_samples_split=10,
    max_depth=15,
    random_state=42,
    max_features=int(np.sqrt(X_train_scaled.shape[1]))   # This is the correct parameter name
)

sklearn_dt.fit(X_train_scaled, y_train)
y_pred_sklearn = sklearn_dt.predict(X_test_scaled)
sklearn_accuracy = accuracy_score(y_test, y_pred_sklearn)

print(f"Sklearn Decision Tree Accuracy: {sklearn_accuracy:.4f}")
print("\
Classification Report:")
print(classification_report(y_test, y_pred_sklearn, zero_division=0))



# Random Forest implementation for lung cancer survival prediction


print("Training Random Forest model...")

# Train Random Forest
rf = RandomForestClassifier(
    n_estimators=100,
    max_depth=15,
    min_samples_split=10,
    random_state=42,
    n_jobs=-1
)

rf.fit(X_train_scaled, y_train)
y_pred_rf = rf.predict(X_test_scaled)

# Evaluate performance
rf_accuracy = accuracy_score(y_test, y_pred_rf)
print(f"Random Forest Accuracy: {rf_accuracy:.4f}")
print("\
Classification Report:")
print(classification_report(y_test, y_pred_rf, zero_division=0))



# PCA implementation for lung cancer dataset
from sklearn.preprocessing import StandardScaler
print("Applying PCA to lung cancer dataset...")

# Apply PCA to the scaled training data
pca = PCA()
X_train_pca = pca.fit_transform(X_train_scaled)
X_test_pca = pca.transform(X_test_scaled)

# Calculate explained variance ratio
explained_variance_ratio = pca.explained_variance_ratio_
cumulative_variance = np.cumsum(explained_variance_ratio)

print(f"Total features: {len(feature_columns)}")
print(f"Explained variance by first 5 components: {cumulative_variance[:5]}")
print(f"Components needed for 95% variance: {np.argmax(cumulative_variance >= 0.95) + 1}")
print(f"Components needed for 99% variance: {np.argmax(cumulative_variance >= 0.99) + 1}")

# Visualize PCA results
plt.figure(figsize=(12, 5))

# Plot 1: Explained variance ratio
plt.subplot(1, 2, 1)
plt.bar(range(1, len(explained_variance_ratio) + 1), explained_variance_ratio)
plt.xlabel('Principal Component')
plt.ylabel('Explained Variance Ratio')
plt.title('PCA Explained Variance by Component')
plt.xticks(range(1, len(explained_variance_ratio) + 1))

# Plot 2: Cumulative explained variance
plt.subplot(1, 2, 2)
plt.plot(range(1, len(cumulative_variance) + 1), cumulative_variance, 'bo-')
plt.axhline(y=0.95, color='r', linestyle='--', label='95% variance')
plt.axhline(y=0.99, color='g', linestyle='--', label='99% variance')
plt.xlabel('Number of Components')
plt.ylabel('Cumulative Explained Variance')
plt.title('Cumulative Explained Variance')
plt.legend()
plt.grid(True)
plt.xticks(range(1, len(cumulative_variance) + 1))

plt.tight_layout()
plt.show()


# Naive Bayes implementation for lung cancer survival prediction


print("Training Naive Bayes model...")

# Train Gaussian Naive Bayes
nb = GaussianNB()
nb.fit(X_train_scaled, y_train)
y_pred_nb = nb.predict(X_test_scaled)

# Evaluate performance
nb_accuracy = accuracy_score(y_test, y_pred_nb)
print(f"Naive Bayes Accuracy: {nb_accuracy:.4f}")
print("\
Classification Report:")
print(classification_report(y_test, y_pred_nb, zero_division=0))

# XGBoost implementation


print("Training XGBoost model...")

xgb_model = xgb.XGBClassifier(
    n_estimators=100,
    max_depth=6,
    learning_rate=0.1,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    eval_metric='logloss'
)

xgb_model.fit(X_train_scaled, y_train)
y_pred_xgb = xgb_model.predict(X_test_scaled)

xgb_accuracy = accuracy_score(y_test, y_pred_xgb)
print(f"XGBoost Accuracy: {xgb_accuracy:.4f}")
print("\
Classification Report:")
print(classification_report(y_test, y_pred_xgb, zero_division=0))

# Check survival distribution and create filtered dataset for non-survived patients
print("Survival distribution:")
print(df['survived'].value_counts())
print("\
Survival percentages:")
print(df['survived'].value_counts(normalize=True) * 100)

# Filter for non-survived patients only (survived = 0)
non_survived_df = df[df['survived'] == 0]
print(f"\
Filtered dataset for non-survived patients:")
print(f"Total non-survived records: {len(non_survived_df)}")
print(f"Shape: {non_survived_df.shape}")

# Save the filtered dataset
non_survived_df.to_csv('non_survived_patients.csv', index=False)
print("\
Saved filtered dataset as 'non_survived_patients.csv'")

# Show sample of non-survived data
print("\
Sample of non-survived patients:")
print(non_survived_df.head())

# 1. Load your data
df = pd.read_csv('dataset_med.csv')  # adjust path if needed

# 2. Select numeric features and the target
features = ['age', 'bmi', 'cholesterol_level']
df_num = df[features + ['survived']].dropna()

# 3. (Optional) Sample for faster plotting
sample_df = df_num.sample(n=20000, random_state=42)

# 4. Marker mapping by survival status
markers = {0: 'x', 1: 'o'}

# ——— 5. 2D PCA scatter plot ———
pca2 = PCA(n_components=2)
pcs2 = pca2.fit_transform(sample_df[features])

plt.figure()
for label, marker in markers.items():
    mask = sample_df['survived'] == label
    plt.scatter(pcs2[mask, 0], pcs2[mask, 1],
                marker=marker, label=f"Survived={label}", alpha=0.6)
plt.title("2D PCA of Age, BMI, Cholesterol")
plt.xlabel("PC 1")
plt.ylabel("PC 2")
plt.legend()
plt.tight_layout()
plt.show()

# ——— 6. 3D PCA scatter plot ———
pca3 = PCA(n_components=3)
pcs3 = pca3.fit_transform(sample_df[features])

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
for label, marker in markers.items():
    mask = sample_df['survived'] == label
    ax.scatter(pcs3[mask, 0], pcs3[mask, 1], pcs3[mask, 2],
               marker=marker, label=f"Survived={label}", alpha=0.6)
ax.set_title("3D PCA of Age, BMI, Cholesterol")
ax.set_xlabel("PC 1")
ax.set_ylabel("PC 2")
ax.set_zlabel("PC 3")
ax.legend()
plt.tight_layout()
plt.show()

# ——— 7. 2D scatter: Age vs. BMI ———
plt.figure()
for label, marker in markers.items():
    mask = sample_df['survived'] == label
    plt.scatter(sample_df.loc[mask, 'age'], sample_df.loc[mask, 'bmi'],
                marker=marker, label=f"Survived={label}", alpha=0.6)
plt.title("Age vs. BMI by Survival")
plt.xlabel("Age")
plt.ylabel("BMI")
plt.legend()
plt.tight_layout()
plt.show()

# ——— 8. 2D scatter: Cholesterol vs. BMI ———
plt.figure()
for label, marker in markers.items():
    mask = sample_df['survived'] == label
    plt.scatter(sample_df.loc[mask, 'cholesterol_level'], sample_df.loc[mask, 'bmi'],
                marker=marker, label=f"Survived={label}", alpha=0.6)
plt.title("Cholesterol vs. BMI by Survival")
plt.xlabel("Cholesterol Level")
plt.ylabel("BMI")
plt.legend()
plt.tight_layout()
plt.show()

surv_counts = df['survived'].value_counts().sort_index()  # index 0 then 1

# ——— 3. Bar Chart of Survival Counts ———
plt.figure()
surv_counts.plot(kind='bar', width=0.6)
plt.title("Patient Survival Counts")
plt.xlabel("Survived (0 = No, 1 = Yes)")
plt.ylabel("Number of Patients")
plt.xticks([0, 1], ['No', 'Yes'], rotation=0)
plt.tight_layout()
plt.show()

# ——— 4. Pie Chart of Survival Proportions ———
plt.figure()
surv_counts.plot(kind='pie', autopct='%1.1f%%', startangle=90, counterclock=False)
plt.title("Patient Survival Proportions")
plt.ylabel("")  # hide default y-label
plt.legend(labels=['No', 'Yes'], loc='upper right')
plt.tight_layout()
plt.show()